"use strict";exports.id=7501,exports.ids=[7501],exports.modules={91700:(e,t,r)=>{r.d(t,{Z:()=>a});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,r(69224).Z)("Building2",[["path",{d:"M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z",key:"1b4qmf"}],["path",{d:"M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2",key:"i71pzd"}],["path",{d:"M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2",key:"10jefs"}],["path",{d:"M10 6h4",key:"1itunk"}],["path",{d:"M10 10h4",key:"tcdvrf"}],["path",{d:"M10 14h4",key:"kelpxr"}],["path",{d:"M10 18h4",key:"1ulq68"}]])},71532:(e,t,r)=>{r.d(t,{Z:()=>a});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,r(69224).Z)("ChevronLeft",[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]])},23425:(e,t,r)=>{r.d(t,{Z:()=>a});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,r(69224).Z)("ClipboardList",[["rect",{width:"8",height:"4",x:"8",y:"2",rx:"1",ry:"1",key:"tgr4d6"}],["path",{d:"M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2",key:"116196"}],["path",{d:"M12 11h4",key:"1jrz19"}],["path",{d:"M12 16h4",key:"n85exb"}],["path",{d:"M8 11h.01",key:"1dfujw"}],["path",{d:"M8 16h.01",key:"18s6g9"}]])},25658:(e,t,r)=>{r.d(t,{Z:()=>a});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,r(69224).Z)("FolderTree",[["path",{d:"M20 10a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1h-2.5a1 1 0 0 1-.8-.4l-.9-1.2A1 1 0 0 0 15 3h-2a1 1 0 0 0-1 1v5a1 1 0 0 0 1 1Z",key:"hod4my"}],["path",{d:"M20 21a1 1 0 0 0 1-1v-3a1 1 0 0 0-1-1h-2.9a1 1 0 0 1-.88-.55l-.42-.85a1 1 0 0 0-.92-.6H13a1 1 0 0 0-1 1v5a1 1 0 0 0 1 1Z",key:"w4yl2u"}],["path",{d:"M3 5a2 2 0 0 0 2 2h3",key:"f2jnh7"}],["path",{d:"M3 3v13a2 2 0 0 0 2 2h3",key:"k8epm1"}]])},2273:(e,t,r)=>{r.d(t,{Z:()=>a});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,r(69224).Z)("LayoutDashboard",[["rect",{width:"7",height:"9",x:"3",y:"3",rx:"1",key:"10lvy0"}],["rect",{width:"7",height:"5",x:"14",y:"3",rx:"1",key:"16une8"}],["rect",{width:"7",height:"9",x:"14",y:"12",rx:"1",key:"1hutg5"}],["rect",{width:"7",height:"5",x:"3",y:"16",rx:"1",key:"ldoo1y"}]])},48120:(e,t,r)=>{r.d(t,{Z:()=>a});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,r(69224).Z)("LogOut",[["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}],["polyline",{points:"16 17 21 12 16 7",key:"1gabdz"}],["line",{x1:"21",x2:"9",y1:"12",y2:"12",key:"1uyos4"}]])},17280:(e,t,r)=>{r.d(t,{Z:()=>a});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,r(69224).Z)("Map",[["polygon",{points:"3 6 9 3 15 6 21 3 21 18 15 21 9 18 3 21",key:"ok2ie8"}],["line",{x1:"9",x2:"9",y1:"3",y2:"18",key:"w34qz5"}],["line",{x1:"15",x2:"15",y1:"6",y2:"21",key:"volv9a"}]])},98200:(e,t,r)=>{r.d(t,{Z:()=>a});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,r(69224).Z)("Menu",[["line",{x1:"4",x2:"20",y1:"12",y2:"12",key:"1e0a9i"}],["line",{x1:"4",x2:"20",y1:"6",y2:"6",key:"1owob3"}],["line",{x1:"4",x2:"20",y1:"18",y2:"18",key:"yk5zj1"}]])},13746:(e,t,r)=>{r.d(t,{Z:()=>a});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,r(69224).Z)("Settings",[["path",{d:"M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",key:"1qme2f"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]])},89895:(e,t,r)=>{r.d(t,{Z:()=>a});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,r(69224).Z)("Users",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["path",{d:"M16 3.13a4 4 0 0 1 0 7.75",key:"1da9ce"}]])},77613:(e,t,r)=>{r.d(t,{Z:()=>a});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,r(59508).Z)("ChevronRight",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]])},16274:(e,t,r)=>{r.d(t,{default:()=>n.a});var a=r(48026),n=r.n(a)},48026:(e,t,r)=>{let{createProxy:a}=r(86843);e.exports=a("/home/pol/Escritorio/gp-new/node_modules/next/dist/client/link.js")},38052:(e,t,r)=>{r.d(t,{z:()=>s});var a=r(25036),n=r(40002),l=r(69048),o=r(94467),i=r(72245);let d=(0,o.j)("inline-flex items-center justify-center whitespace-nowrap rounded-lg text-sm font-medium transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:pointer-events-none disabled:opacity-50 active:scale-95",{variants:{variant:{default:"bg-accent text-background hover:bg-accent-hover shadow-sm hover:shadow-glow",destructive:"bg-error text-white hover:bg-error/90",outline:"border border-border bg-transparent text-text-primary hover:bg-card hover:border-accent/50",secondary:"bg-card text-text-primary border border-border hover:bg-card-hover hover:border-accent/30",ghost:"text-text-secondary hover:bg-card hover:text-text-primary",link:"text-accent underline-offset-4 hover:underline"},size:{default:"h-10 px-4 py-2",sm:"h-9 rounded-md px-3",lg:"h-11 rounded-lg px-8",icon:"h-10 w-10"}},defaultVariants:{variant:"default",size:"default"}}),s=n.forwardRef(({className:e,variant:t,size:r,asChild:n=!1,...o},s)=>{let c=n?l.g7:"button";return a.jsx(c,{className:(0,i.cn)(d({variant:t,size:r,className:e})),ref:s,...o})});s.displayName="Button"},44551:(e,t,r)=>{r.d(t,{Ol:()=>i,SZ:()=>s,Zb:()=>o,aY:()=>c,ll:()=>d});var a=r(25036),n=r(40002),l=r(72245);let o=n.forwardRef(({className:e,...t},r)=>a.jsx("div",{ref:r,className:(0,l.cn)("rounded-xl border border-border/50 bg-card text-text-primary shadow-card","transition-all duration-300 hover:border-accent/20",e),...t}));o.displayName="Card";let i=n.forwardRef(({className:e,...t},r)=>a.jsx("div",{ref:r,className:(0,l.cn)("flex flex-col space-y-1.5 p-6",e),...t}));i.displayName="CardHeader";let d=n.forwardRef(({className:e,...t},r)=>a.jsx("h3",{ref:r,className:(0,l.cn)("text-xl font-semibold leading-none tracking-tight text-text-primary",e),...t}));d.displayName="CardTitle";let s=n.forwardRef(({className:e,...t},r)=>a.jsx("p",{ref:r,className:(0,l.cn)("text-sm text-text-secondary",e),...t}));s.displayName="CardDescription";let c=n.forwardRef(({className:e,...t},r)=>a.jsx("div",{ref:r,className:(0,l.cn)("p-6 pt-0",e),...t}));c.displayName="CardContent",n.forwardRef(({className:e,...t},r)=>a.jsx("div",{ref:r,className:(0,l.cn)("flex items-center p-6 pt-0",e),...t})).displayName="CardFooter"},72245:(e,t,r)=>{r.d(t,{$G:()=>d,Qm:()=>s,UC:()=>c,cn:()=>l,o0:()=>i,p6:()=>o});var a=r(70990),n=r(81774);function l(...e){return(0,n.m6)((0,a.W)(e))}function o(e){return new Date(e).toLocaleDateString("es-AR",{year:"numeric",month:"short",day:"numeric"})}function i(e){return new Date(e).toLocaleDateString("es-AR",{year:"numeric",month:"short",day:"numeric",hour:"2-digit",minute:"2-digit"})}function d(e,t){return e.length<=t?e:e.slice(0,t)+"..."}function s(e){return e.split(" ").map(e=>e[0]).join("").toUpperCase().slice(0,2)}function c(e){switch(e){case"NEGOCIO":return"Comercio";case"PYME":return"PyME";case"PROFESIONAL":return"Profesional";case"SERVICIO":return"Servicio";default:return e}}},69048:(e,t,r)=>{r.d(t,{g7:()=>c});var a=r(40002),n=r.t(a,2);function l(e,t){if("function"==typeof e)return e(t);null!=e&&(e.current=t)}var o=r(25036),i=Symbol.for("react.lazy"),d=n[" use ".trim().toString()];function s(e){var t;return null!=e&&"object"==typeof e&&"$$typeof"in e&&e.$$typeof===i&&"_payload"in e&&"object"==typeof(t=e._payload)&&null!==t&&"then"in t}var c=function(e){let t=function(e){let t=a.forwardRef((e,t)=>{let{children:r,...n}=e;if(s(r)&&"function"==typeof d&&(r=d(r._payload)),a.isValidElement(r)){var o;let e,i;let d=(o=r,(e=Object.getOwnPropertyDescriptor(o.props,"ref")?.get)&&"isReactWarning"in e&&e.isReactWarning?o.ref:(e=Object.getOwnPropertyDescriptor(o,"ref")?.get)&&"isReactWarning"in e&&e.isReactWarning?o.props.ref:o.props.ref||o.ref),s=function(e,t){let r={...t};for(let a in t){let n=e[a],l=t[a];/^on[A-Z]/.test(a)?n&&l?r[a]=(...e)=>{let t=l(...e);return n(...e),t}:n&&(r[a]=n):"style"===a?r[a]={...n,...l}:"className"===a&&(r[a]=[n,l].filter(Boolean).join(" "))}return{...e,...r}}(n,r.props);return r.type!==a.Fragment&&(s.ref=t?function(...e){return t=>{let r=!1,a=e.map(e=>{let a=l(e,t);return r||"function"!=typeof a||(r=!0),a});if(r)return()=>{for(let t=0;t<a.length;t++){let r=a[t];"function"==typeof r?r():l(e[t],null)}}}}(t,d):d),a.cloneElement(r,s)}return a.Children.count(r)>1?a.Children.only(null):null});return t.displayName=`${e}.SlotClone`,t}(e),r=a.forwardRef((e,r)=>{let{children:n,...l}=e;s(n)&&"function"==typeof d&&(n=d(n._payload));let i=a.Children.toArray(n),c=i.find(h);if(c){let e=c.props.children,n=i.map(t=>t!==c?t:a.Children.count(e)>1?a.Children.only(null):a.isValidElement(e)?e.props.children:null);return(0,o.jsx)(t,{...l,ref:r,children:a.isValidElement(e)?a.cloneElement(e,void 0,n):null})}return(0,o.jsx)(t,{...l,ref:r,children:n})});return r.displayName=`${e}.Slot`,r}("Slot"),y=Symbol("radix.slottable");function h(e){return a.isValidElement(e)&&"function"==typeof e.type&&"__radixId"in e.type&&e.type.__radixId===y}}};