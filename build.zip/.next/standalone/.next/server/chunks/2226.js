"use strict";exports.id=2226,exports.ids=[2226],exports.modules={42739:(e,t,r)=>{r.d(t,{Z:()=>n});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,r(69224).Z)("Loader2",[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]])},38271:(e,t,r)=>{r.d(t,{Z:()=>n});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,r(69224).Z)("Trash2",[["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6",key:"4alrt4"}],["path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2",key:"v07s0e"}],["line",{x1:"10",x2:"10",y1:"11",y2:"17",key:"1uufr5"}],["line",{x1:"14",x2:"14",y1:"11",y2:"17",key:"xtxkd"}]])},30080:(e,t,r)=>{/**
 * @license React
 * use-sync-external-store-shim.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var n=r(3729);"function"==typeof Object.is&&Object.is,n.useState,n.useEffect,n.useLayoutEffect,n.useDebugValue,t.useSyncExternalStore=void 0!==n.useSyncExternalStore?n.useSyncExternalStore:function(e,t){return t()}},8145:(e,t,r)=>{e.exports=r(30080)},89273:(e,t,r)=>{r.d(t,{Z:()=>n});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,r(59508).Z)("Mail",[["rect",{width:"20",height:"16",x:"2",y:"4",rx:"2",key:"18n3k1"}],["path",{d:"m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7",key:"1ocrg3"}]])},81272:(e,t,r)=>{r.d(t,{Z:()=>n});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,r(59508).Z)("Pencil",[["path",{d:"M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z",key:"5qss01"}],["path",{d:"m15 5 4 4",key:"1mk7zo"}]])},59608:(e,t,r)=>{r.d(t,{Z:()=>n});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,r(59508).Z)("Phone",[["path",{d:"M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z",key:"foiqr5"}]])},2306:(e,t,r)=>{r.d(t,{Z:()=>n});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,r(59508).Z)("Plus",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]])},6682:(e,t,r)=>{r.d(t,{Z:()=>n});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,r(59508).Z)("Users",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["path",{d:"M16 3.13a4 4 0 0 1 0 7.75",key:"1da9ce"}]])},16274:(e,t,r)=>{r.d(t,{default:()=>l.a});var n=r(48026),l=r.n(n)},48026:(e,t,r)=>{let{createProxy:n}=r(86843);e.exports=n("/home/pol/Escritorio/gp-new/node_modules/next/dist/client/link.js")},57987:(e,t,r)=>{r.d(t,{NY:()=>w,Ee:()=>E,fC:()=>S});var n=r(3729),l=r(95344),o=r(2256),a=r(16069),i=r(62409),u=r(8145);function s(){return()=>{}}var d="Avatar",[c,f]=function(e,t=[]){let r=[],o=()=>{let t=r.map(e=>n.createContext(e));return function(r){let l=r?.[e]||t;return n.useMemo(()=>({[`__scope${e}`]:{...r,[e]:l}}),[r,l])}};return o.scopeName=e,[function(t,o){let a=n.createContext(o);a.displayName=t+"Context";let i=r.length;r=[...r,o];let u=t=>{let{scope:r,children:o,...u}=t,s=r?.[e]?.[i]||a,d=n.useMemo(()=>u,Object.values(u));return(0,l.jsx)(s.Provider,{value:d,children:o})};return u.displayName=t+"Provider",[u,function(r,l){let u=l?.[e]?.[i]||a,s=n.useContext(u);if(s)return s;if(void 0!==o)return o;throw Error(`\`${r}\` must be used within \`${t}\``)}]},function(...e){let t=e[0];if(1===e.length)return t;let r=()=>{let r=e.map(e=>({useScope:e(),scopeName:e.scopeName}));return function(e){let l=r.reduce((t,{useScope:r,scopeName:n})=>{let l=r(e)[`__scope${n}`];return{...t,...l}},{});return n.useMemo(()=>({[`__scope${t.scopeName}`]:l}),[l])}};return r.scopeName=t.scopeName,r}(o,...t)]}(d),[p,y]=c(d),m=n.forwardRef((e,t)=>{let{__scopeAvatar:r,...o}=e,[a,u]=n.useState("idle");return(0,l.jsx)(p,{scope:r,imageLoadingStatus:a,onImageLoadingStatusChange:u,children:(0,l.jsx)(i.WV.span,{...o,ref:t})})});m.displayName=d;var h="AvatarImage",v=n.forwardRef((e,t)=>{let{__scopeAvatar:r,src:d,onLoadingStatusChange:c=()=>{},...f}=e,p=y(h,r),m=function(e,{referrerPolicy:t,crossOrigin:r}){let l=(0,u.useSyncExternalStore)(s,()=>!0,()=>!1),o=n.useRef(null),i=l?(o.current||(o.current=new window.Image),o.current):null,[d,c]=n.useState(()=>k(i,e));return(0,a.b)(()=>{c(k(i,e))},[i,e]),(0,a.b)(()=>{let e=e=>()=>{c(e)};if(!i)return;let n=e("loaded"),l=e("error");return i.addEventListener("load",n),i.addEventListener("error",l),t&&(i.referrerPolicy=t),"string"==typeof r&&(i.crossOrigin=r),()=>{i.removeEventListener("load",n),i.removeEventListener("error",l)}},[i,r,t]),d}(d,f),v=(0,o.W)(e=>{c(e),p.onImageLoadingStatusChange(e)});return(0,a.b)(()=>{"idle"!==m&&v(m)},[m,v]),"loaded"===m?(0,l.jsx)(i.WV.img,{...f,ref:t,src:d}):null});v.displayName=h;var g="AvatarFallback",x=n.forwardRef((e,t)=>{let{__scopeAvatar:r,delayMs:o,...a}=e,u=y(g,r),[s,d]=n.useState(void 0===o);return n.useEffect(()=>{if(void 0!==o){let e=window.setTimeout(()=>d(!0),o);return()=>window.clearTimeout(e)}},[o]),s&&"loaded"!==u.imageLoadingStatus?(0,l.jsx)(i.WV.span,{...a,ref:t}):null});function k(e,t){return e?t?(e.src!==t&&(e.src=t),e.complete&&e.naturalWidth>0?"loaded":"loading"):"error":"idle"}x.displayName=g;var S=m,E=v,w=x},69048:(e,t,r)=>{r.d(t,{g7:()=>d});var n=r(40002),l=r.t(n,2);function o(e,t){if("function"==typeof e)return e(t);null!=e&&(e.current=t)}var a=r(25036),i=Symbol.for("react.lazy"),u=l[" use ".trim().toString()];function s(e){var t;return null!=e&&"object"==typeof e&&"$$typeof"in e&&e.$$typeof===i&&"_payload"in e&&"object"==typeof(t=e._payload)&&null!==t&&"then"in t}var d=function(e){let t=function(e){let t=n.forwardRef((e,t)=>{let{children:r,...l}=e;if(s(r)&&"function"==typeof u&&(r=u(r._payload)),n.isValidElement(r)){var a;let e,i;let u=(a=r,(e=Object.getOwnPropertyDescriptor(a.props,"ref")?.get)&&"isReactWarning"in e&&e.isReactWarning?a.ref:(e=Object.getOwnPropertyDescriptor(a,"ref")?.get)&&"isReactWarning"in e&&e.isReactWarning?a.props.ref:a.props.ref||a.ref),s=function(e,t){let r={...t};for(let n in t){let l=e[n],o=t[n];/^on[A-Z]/.test(n)?l&&o?r[n]=(...e)=>{let t=o(...e);return l(...e),t}:l&&(r[n]=l):"style"===n?r[n]={...l,...o}:"className"===n&&(r[n]=[l,o].filter(Boolean).join(" "))}return{...e,...r}}(l,r.props);return r.type!==n.Fragment&&(s.ref=t?function(...e){return t=>{let r=!1,n=e.map(e=>{let n=o(e,t);return r||"function"!=typeof n||(r=!0),n});if(r)return()=>{for(let t=0;t<n.length;t++){let r=n[t];"function"==typeof r?r():o(e[t],null)}}}}(t,u):u),n.cloneElement(r,s)}return n.Children.count(r)>1?n.Children.only(null):null});return t.displayName=`${e}.SlotClone`,t}(e),r=n.forwardRef((e,r)=>{let{children:l,...o}=e;s(l)&&"function"==typeof u&&(l=u(l._payload));let i=n.Children.toArray(l),d=i.find(f);if(d){let e=d.props.children,l=i.map(t=>t!==d?t:n.Children.count(e)>1?n.Children.only(null):n.isValidElement(e)?e.props.children:null);return(0,a.jsx)(t,{...o,ref:r,children:n.isValidElement(e)?n.cloneElement(e,void 0,l):null})}return(0,a.jsx)(t,{...o,ref:r,children:l})});return r.displayName=`${e}.Slot`,r}("Slot"),c=Symbol("radix.slottable");function f(e){return n.isValidElement(e)&&"function"==typeof e.type&&"__radixId"in e.type&&e.type.__radixId===c}}};